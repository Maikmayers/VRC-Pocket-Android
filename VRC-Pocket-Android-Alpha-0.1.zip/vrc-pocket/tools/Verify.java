import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.JavacTask;

/** Offline syntax validation; deliberately does not claim Android type checking. */
public class Verify {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("JDK 17 required");
        List<java.io.File> files=new ArrayList<>();
        try(var stream=Files.walk(Path.of("app/src"))){stream.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toFile()));}
        DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
        try(StandardJavaFileManager fm=compiler.getStandardFileManager(diagnostics,null,null)){
            JavacTask task=(JavacTask)compiler.getTask(null,fm,diagnostics,List.of("-proc:none","--release","17"),null,fm.getJavaFileObjectsFromFiles(files));
            task.parse();
            boolean bad=false;
            for(var d:diagnostics.getDiagnostics())if(d.getKind()==Diagnostic.Kind.ERROR){System.err.println(d);bad=true;}
            if(bad)throw new AssertionError("Java parse failed");
        }
        System.out.println("PASS: Java 17 syntax, "+files.size()+" files (not an Android build)");
    }
}
