package de.vrcpocket;
import java.util.*;

public class PolicyChecks {
    private static int count;
    static void check(boolean value,String name){if(!value)throw new AssertionError(name);count++;}
    public static void main(String[] args){
        AlertPolicy p=new AlertPolicy();Set<String> none=Collections.emptySet();
        check(!p.presence("a","offline",false,none),"no initial snapshot alert");
        check(p.presence("a","world1",false,none),"online transition alerts");
        check(!p.presence("a","world1",false,none),"duplicate presence suppressed");
        check(p.presence("a","world2",false,none),"world change alerts");
        check(!p.presence("a","offline",true,none),"watch filter excludes");
        check(p.presence("a","world1",true,Set.of("a")),"watched friend included");
        check(p.presence("a","offline",true,Set.of("a")),"watched friend offline");
        p.baseline("a","world2");check(!p.presence("a","world2",false,none),"reconnect baseline is silent");
        check(p.notification("n1"),"new notification");check(!p.notification("n1"),"duplicate notification");
        check(!p.notification(""),"invalid notification");
        for(int i=0;i<800;i++)p.notification("n"+i);
        check(!p.notification("n799"),"bounded cache retains recent ID");
        check(AlertPolicy.retryDelay(0)==1000,"initial retry");
        check(AlertPolicy.retryDelay(3)==8000,"exponential retry");
        check(AlertPolicy.retryDelay(99)==60000,"retry upper bound");
        check(AlertPolicy.retryDelay(-3)==1000,"retry lower bound");
        check(AlertPolicy.safeLocation("private","Private","Offline").equals("Private"),"private stays private");
        check(AlertPolicy.safeLocation(null,"Private","Offline").equals("Offline"),"null location");
        check(AlertPolicy.safeLocation("offline","Private","Offline").equals("Offline"),"offline location");
        check(AlertPolicy.safeLocation("wrld_123:456","Private","Offline").equals("wrld_123:456"),"visible location");
        System.out.println("PASS: "+count+" behavioral checks");
    }
}
