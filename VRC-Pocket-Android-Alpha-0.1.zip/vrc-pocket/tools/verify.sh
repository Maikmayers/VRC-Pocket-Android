#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p /tmp/vrc-pocket-checks
java tools/Verify.java
java com.sun.tools.javac.Main -d /tmp/vrc-pocket-checks app/src/main/java/de/vrcpocket/AlertPolicy.java tools/PolicyChecks.java
java -cp /tmp/vrc-pocket-checks de.vrcpocket.PolicyChecks
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('PASS: Android XML parsed')
PY
