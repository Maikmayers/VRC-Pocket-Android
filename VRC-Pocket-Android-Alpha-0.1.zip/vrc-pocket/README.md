# VRC Pocket · Android Alpha 0.1

Native, unabhängige VRChat-Companion-App für Android 8 oder neuer. Oberfläche zur Laufzeit auf **Deutsch und Englisch** umschaltbar. Vorläufiger Projektname, keine Verbindung zu VRChat Inc. oder VRCNext.

## Was im Quellcode umgesetzt ist

| Bereich | Alpha-Funktion |
|---|---|
| Anmeldung | VRChat-Benutzername/Passwort; Authenticator-, E-Mail- und angebotene Wiederherstellungscodes; Sitzungswiederaufnahme |
| Freunde | Online-/Offline-Seiten, Status, Auswahl beobachteter Freunde, sichtbaren Standort mit Weltname auf Abruf anzeigen, VRChat-Profil öffnen |
| Aktivitäten | Sichtbarer Vordergrunddienst, VRChat-WebSocket, Verbindungsanzeige, automatische Wiederverbindung mit begrenztem exponentiellem Abstand |
| Benachrichtigungen | Online/offline, optional Weltwechsel; Filter für beobachtete Freunde; Boops, Eventmeldungen, Einladungen/weitere Benachrichtigungen |
| Boops | Senden nach Bestätigung; Standard-Boop ohne eigene Emoji-Auswahl; Empfangsmeldungen |
| Welten | Suche, VRChat-Favoriten ansehen, zu vorhandener Weltfavoritengruppe hinzufügen, entfernen |
| Events | VRChat-Kontokalender nach Monat, lokale Zeit, Kalenderentwurf im Handy-Kalender öffnen |
| Profil | Online-/Privatsphärenstatus und Statustext ändern |
| Inbox | VRChat-Benachrichtigungen beider API-Generationen; letzte 100 lokal erfasste Meldungen |
| Sprache | Deutsch/English in Anmeldung und Profil |

**Dies ist ein Quellcode-Alpha-Projekt, keine bereits gebaute oder auf einem Gerät erprobte APK.** Es ist keine vollständige VRCNext-Portierung. Funktionen, die VRChat über seine Schnittstellen nicht liefert, werden nicht umgangen. Eine API-Antwort „private“ bleibt privat.

## APK am PC bauen

Am einfachsten den entpackten Ordner `vrc-pocket` mit einer aktuellen Android-Studio-Version öffnen, die Android Gradle Plugin 8.9 unterstützt.

1. JDK 17, Android SDK Platform 35 und Build Tools über Android Studio einrichten.
2. Für das erste Öffnen ist Internetzugang zu Google Maven, Maven Central und Gradle erforderlich.
3. Android Studio kann beim Import eine Gradle-Distribution konfigurieren. Benötigt wird **Gradle 8.11.1**. Ein heruntergeladenes Wrapper-JAR ist in diesem Paket nicht enthalten.
4. Falls Android Studio eine lokale Gradle-Installation benötigt: Gradle 8.11.1 installieren, im Projektverzeichnis `gradle wrapper --gradle-version 8.11.1` ausführen, dann erneut importieren.
5. Mit `gradle :app:testDebugUnitTest :app:lintDebug :app:assembleDebug` prüfen und bauen. Nach Wrapper-Erzeugung geht auch `./gradlew` statt `gradle`.
6. Ergebnis: `app/build/outputs/apk/debug/app-debug.apk`. Diese Debug-APK ist für private Tests installierbar. Für dauerhafte Verteilung einen eigenen beständigen Release-Schlüssel verwenden.

Keine Passwörter oder Tokens in Build-Dateien oder GitHub-Secrets eintragen. Die App fragt diese erst auf dem Handy ab.

## APK mit GitHub Actions bauen

Die Datei `.github/workflows/android.yml` liegt bei. Den **Inhalt** des Projektordners in das Stammverzeichnis eines eigenen GitHub-Repositories übernehmen; dabei auch den Ordner `.github` einschließen. Danach unter **Actions → Android APK** den Build ausführen. Nach erfolgreichem Build das Artefakt **VRC-Pocket-Android-APK** herunterladen, ZIP entpacken und die darin enthaltene APK auf dem Handy installieren. Ein Build wurde in dieser Umgebung weder veröffentlicht noch remote ausgeführt.

## Auf dem Handy

1. APK installieren und VRC Pocket öffnen.
2. Mit einem VRChat-Konto anmelden. Steam-/Meta-Anmeldung ohne verknüpften VRChat-Benutzernamen wird nicht unterstützt.
3. Sprache über **Deutsch / English** wählen.
4. Unter **Profil → Überwachung starten** Benachrichtigungen erlauben.
5. Unter Android-App-Info Benachrichtigungen und gegebenenfalls die Akku-Hintergrundnutzung freigeben. Hersteller verwenden dafür verschiedene Bezeichnungen.
6. Optional Freunde mit dem Stern auswählen und **Nur ausgewählte Freunde melden** aktivieren.

Die laufende Überwachung zeigt eine dauerhafte Meldung mit einer Stopptaste. Ohne diese Überwachung bleibt die App zum manuellen Abrufen nutzbar. Nach Geräte-Neustart, erzwungenem Beenden oder Stoppen durch Android muss sie erneut gestartet werden. Das ist in dieser Alpha bewusst sichtbar und nicht als automatische Verfügbarkeit dargestellt.

## Zuverlässigkeit und Grenzen

- Keine Garantie auf lückenlose oder sofortige Zustellung: Android, Netzverbindung und VRChat sind beteiligt.
- Nach einer Unterbrechung werden Freunde erneut eingelesen; dieser Ausgangsstand bleibt still. Weltwechsel während der Unterbrechung werden nicht nachträglich erfunden.
- Die jüngsten bis zu 100 klassischen und 100 V2-Benachrichtigungen werden beim Wiederverbinden auf neue IDs geprüft. Beim allerersten Start werden vorhandene Meldungen still als Ausgangsstand erfasst.
- Der Dienst unterdrückt wiederholte identische Präsenzmeldungen. Die Verbindungsanzeige warnt bei ausbleibendem Dienst-Lebenszeichen.
- Bei abgelaufener Sitzung fordert die App eine neue Anmeldung; sie speichert kein Passwort für eine automatische Anmeldung.
- Der Eventbereich zeigt den Kontokalender, keine vollständige Suche aller öffentlichen Events. Eigene Eventvorwarnungen werden in dieser Alpha nicht im App-Hintergrund geplant. Termine können mit dem Systemkalender bestätigt und dort mit Erinnerungen versehen werden.
- Online-/Standortliste wird beim Öffnen oder über **Aktualisieren** geladen; die Hintergrundüberwachung aktualisiert die Benachrichtigungen, nicht automatisch die gerade sichtbare Liste.
- Boop-Bestätigung/Acknowledge, Einladungsannahme, eine eigene Emoji-Auswahl, Avatarverwaltung und ein Neustart-Autostart sind noch nicht enthalten.
- Androids `specialUse`-Vordergrunddienst ist für vom Nutzer gestartete fortlaufende Überwachung deklariert. Eine spätere Play-Store-Veröffentlichung benötigt deren Prüfung; sie ist nicht Teil dieser privaten Alpha.

## Daten und Sicherheit

Kommunikation direkt vom Handy mit `api.vrchat.cloud` und `pipeline.vrchat.cloud` über TLS. Keine eigenen Backend-Server, Werbung oder Analysedienste. Keine unverschlüsselten HTTP-Verbindungen. Authentifizierungscookies sind AES-GCM-verschlüsselt, der Schlüssel liegt im Android Keystore; Android-Backups sind deaktiviert. Passwort und 2FA-Code werden nicht persistent gespeichert. HTTP-Redirects sind deaktiviert, um Sitzungscookies und Basic-Credentials nicht an fremde Hosts weiterzureichen. Cookies sind auf den API-Host beschränkt. Keine Token-/WebSocket-Inhalte werden protokolliert.

Freundesauswahl, Benachrichtigungs-IDs und der lokale Aktivitätsverlauf befinden sich in privaten App-Daten. Der Verlauf ist löschbar; Abmelden entfernt kontobezogene lokale Daten. Inhalte von VRChat werden nicht automatisch übersetzt. Bereits gespeicherte lokale Meldungen behalten ihre ursprüngliche Sprache. Für die Alpha sind Screenshots der App durch `FLAG_SECURE` gesperrt.

## Prüfstand

Lokal in der Entwicklungsumgebung erfolgreich ausgeführt:

- Java-17-Syntaxprüfung aller sieben App-/Testquelldateien.
- 20 tatsächliche Java-Prüfungen der Benachrichtigungslogik: Ausgangsstände, Online-/Offline-/Weltwechsel, Freundesfilter, Wiederverbindungs-Ausgangsstand, doppelte Benachrichtigungen, Cachebegrenzung, Wiederholungsintervalle und private Standorte.
- XML-Parsing von Manifest, Theme und Icon.

Wiederholbar mit `sh tools/verify.sh` (JDK 17 und Python 3). Das ist **kein Android-Compilerlauf** und ersetzt keinen Android-Build.

Noch nicht ausgeführt: Gradle-Abhängigkeitsauflösung, Android-Kompilierung/Lint, Installation, Anmeldung an einem echten Konto und Langzeittests auf dem Handy. Hier fehlen SDK/Gradle; Downloads der benötigten Werkzeuge waren nicht erreichbar. Die CI-Datei führt die vollständigen Build-Prüfungen aus, sobald das Projekt in einem geeigneten Runner liegt.

## Abnahmetest auf einem echten Gerät

1. Anmeldung, falsches Passwort, falscher und korrekter 2FA-Code, App schließen/öffnen, danach abmelden.
2. Mit einem Testfreund Online-/Offline-Wechsel und sichtbaren/privaten Weltwechsel auslösen. Stummfilter und beobachtete Freunde vergleichen.
3. Display mindestens 30 Minuten sperren; WLAN/Mobilfunk wechseln; Flugmodus einschalten/ausschalten; Meldungszeiten vergleichen.
4. Boop senden/empfangen; mit offenen nicht bestätigten Boops die VRChat-Fehlermeldung prüfen.
5. Welt suchen, Favorit hinzufügen und nach Aktualisierung in VRChat gegenprüfen, danach entfernen.
6. Event im Kontokalender öffnen; Zeitzone und Sommer-/Winterzeit vergleichen; Systemkalenderentwurf prüfen und bestätigen.
7. Status ändern und in VRChat prüfen. Sprache wechseln, App neu starten.
8. Benachrichtigungsrecht widerrufen, Dienst stoppen, Prozess von Android beenden, Gerät neu starten: Die App darf keinen unbestätigten Live-Zustand versprechen.

## Technische Quellen

Die folgenden Community-Spezifikationen dokumentieren die verwendeten VRChat-Endpunkte, sind jedoch kein Verfügbarkeitsversprechen von VRChat:

- https://vrchat.community/reference/get-current-user
- https://vrchat.community/reference/verify2fa
- https://vrchat.community/websocket
- https://vrchat.community/reference/boop
- https://vrchat.community/reference/get-calendar-events
- https://vrchat.community/reference/get-notification-v2s
- https://vrchat.community/reference/update-user
- https://vrchat.community/reference/get-favorite-groups
- https://vrchat.community/reference/get-favorited-worlds
- https://vrchat.community/reference/add-favorite

Technik: Java 17, Android SDK 35, Android Gradle Plugin 8.9.2, Gradle 8.11.1, OkHttp 4.12.0. Kein Unity und kein laufender VRChat-PC-Client nötig.
