package de.vrcpocket;
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.*;
public class AlertPolicyTest {
    @Test public void initialSnapshotsAreSilentAndTransitionsNotify(){
        AlertPolicy p=new AlertPolicy();
        assertFalse(p.presence("a","offline",false,Set.of()));
        assertTrue(p.presence("a","online",false,Set.of()));
        assertFalse(p.presence("a","online",false,Set.of()));
        assertTrue(p.presence("a","offline",false,Set.of()));
    }
    @Test public void watchFilterAndRecoveryBaseline(){
        AlertPolicy p=new AlertPolicy();p.baseline("a","offline");
        assertFalse(p.presence("a","online",true,Set.of("b")));
        assertTrue(p.presence("a","offline",true,Set.of("a")));
        p.baseline("a","online");assertFalse(p.presence("a","online",false,Set.of()));
    }
    @Test public void suppressDuplicateNotifications(){AlertPolicy p=new AlertPolicy();assertTrue(p.notification("n1"));assertFalse(p.notification("n1"));assertFalse(p.notification(""));}
    @Test public void retriesBounded(){assertEquals(1000,AlertPolicy.retryDelay(0));assertEquals(60000,AlertPolicy.retryDelay(80));}
    @Test public void privacyBoundaries(){assertEquals("Private",AlertPolicy.safeLocation("private","Private","Offline"));}
}
