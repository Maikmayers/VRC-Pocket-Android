package de.vrcpocket;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;

/** Only VRChat API cookies; encrypted at rest with a non-exportable device key. */
public final class SecureCookies implements CookieJar {
    private final SharedPreferences disk;
    private final List<Cookie> cookies = new ArrayList<>();
    private boolean accepting = true;
    private static final HttpUrl ORIGIN = HttpUrl.get("https://api.vrchat.cloud/api/1/auth/user");
    public SecureCookies(Context context) {
        disk = context.getSharedPreferences("session", Context.MODE_PRIVATE);
        try {
            String raw = disk.getString("vault", "");
            if (!raw.isEmpty()) {
                String[] pieces = raw.split(":");
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(pieces[0], Base64.NO_WRAP)));
                JSONArray list = new JSONArray(new String(cipher.doFinal(Base64.decode(pieces[1], Base64.NO_WRAP)), java.nio.charset.StandardCharsets.UTF_8));
                for (int i = 0; i < list.length(); i++) {
                    Cookie c = Cookie.parse(ORIGIN, list.getString(i));
                    if (c != null && c.matches(ORIGIN) && c.expiresAt() > System.currentTimeMillis()) cookies.add(c);
                }
            }
        } catch (Exception ignored) { disk.edit().clear().commit(); cookies.clear(); }
    }
    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias("vrc-pocket-session")) return (SecretKey) ks.getKey("vrc-pocket-session", null);
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder("vrc-pocket-session", KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return gen.generateKey();
    }
    private void persist() {
        try {
            JSONArray list = new JSONArray(); for (Cookie c : cookies) list.put(c.toString());
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key());
            byte[] data = cipher.doFinal(list.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8));
            disk.edit().putString("vault", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(data, Base64.NO_WRAP)).commit();
        } catch (Exception e) { disk.edit().clear().commit(); throw new IllegalStateException("Session storage unavailable", e); }
    }
    @Override public synchronized void saveFromResponse(HttpUrl url, List<Cookie> incoming) {
        if (!accepting || !url.host().equals(ORIGIN.host())) return;
        for (Cookie c : incoming) {
            if (!c.name().equals("auth") && !c.name().equals("twoFactorAuth")) continue;
            cookies.removeIf(old -> old.name().equals(c.name()));
            if (c.expiresAt() > System.currentTimeMillis()) cookies.add(c);
        }
        persist();
    }
    @Override public synchronized List<Cookie> loadForRequest(HttpUrl url) {
        List<Cookie> result = new ArrayList<>();
        if (!url.host().equals(ORIGIN.host())) return result;
        for (Cookie c : cookies) if (c.matches(url) && c.expiresAt() > System.currentTimeMillis()) result.add(c);
        return result;
    }
    public synchronized String auth() {
        for (Cookie c : cookies) if (c.name().equals("auth") && c.expiresAt() > System.currentTimeMillis()) return c.value();
        return "";
    }
    public synchronized void beginLogin() { accepting = true; }
    public synchronized void clear() { accepting = false; cookies.clear(); disk.edit().clear().commit(); }
}
