package de.vrcpocket;

import android.app.Application;
import android.content.SharedPreferences;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PocketApp extends Application {
    public Api api;
    public SharedPreferences prefs;
    public final ExecutorService io = Executors.newSingleThreadExecutor();
    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        api = new Api(new SecureCookies(this));
    }
    public String t(String de, String en) { return prefs.getString("language", "de").equals("de") ? de : en; }
}
