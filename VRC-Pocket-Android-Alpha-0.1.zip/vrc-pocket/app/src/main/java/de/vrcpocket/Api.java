package de.vrcpocket;

import org.json.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

public final class Api {
    static final String BASE = "https://api.vrchat.cloud/api/1";
    static final String UA = "VRCPocket/0.1.0 (Android; personal companion alpha)";
    final SecureCookies cookies;
    final OkHttpClient http;
    public Api(SecureCookies jar) {
        cookies = jar;
        http = new OkHttpClient.Builder().cookieJar(jar).connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS).pingInterval(25, TimeUnit.SECONDS)
            .followRedirects(false).followSslRedirects(false).build();
    }
    public static class ApiError extends IOException {
        public final int status;
        ApiError(int status) { super("HTTP " + status); this.status = status; }
    }
    static String q(String value) {
        try { return URLEncoder.encode(value, "UTF-8"); } catch (java.io.UnsupportedEncodingException e) { throw new AssertionError(e); }
    }
    static String id(String value, String prefix) {
        if (!value.matches(prefix + "_[a-fA-F0-9-]{36}")) throw new IllegalArgumentException("Invalid ID");
        return value;
    }
    Object request(String method, String path, JSONObject body, String basic) throws Exception {
        Request.Builder b = new Request.Builder().url(BASE + path).header("User-Agent", UA).header("Accept", "application/json");
        if (basic != null) b.header("Authorization", basic);
        RequestBody data = body == null ? null : RequestBody.create(body.toString(), MediaType.get("application/json; charset=utf-8"));
        b.method(method, data);
        try (Response response = http.newCall(b.build()).execute()) {
            if (!response.isSuccessful()) throw new ApiError(response.code());
            String raw = response.body() == null ? "{}" : response.body().string();
            return raw.trim().isEmpty() ? new JSONObject() : new JSONTokener(raw).nextValue();
        }
    }
    public JSONObject me() throws Exception { return (JSONObject) request("GET", "/auth/user", null, null); }
    public JSONObject login(String user, String password) throws Exception {
        cookies.beginLogin();
        return (JSONObject) request("GET", "/auth/user", null, Credentials.basic(q(user).replace("+", "%20").replace("*", "%2A"), q(password).replace("+", "%20").replace("*", "%2A")));
    }
    public JSONObject verify(String type, String code) throws Exception {
        if (!type.equals("totp") && !type.equals("emailotp") && !type.equals("otp")) throw new IllegalArgumentException();
        JSONObject result = (JSONObject) request("POST", "/auth/twofactorauth/" + type + "/verify", new JSONObject().put("code", code), null);
        if (!result.optBoolean("verified")) throw new IOException("Code not verified");
        return me();
    }
    public JSONArray friends(boolean offline, int offset) throws Exception {
        return (JSONArray) request("GET", "/auth/user/friends?offline=" + offline + "&n=100&offset=" + offset, null, null);
    }
    public JSONArray worlds(String search, int offset) throws Exception {
        return (JSONArray) request("GET", "/worlds?search=" + q(search) + "&n=50&offset=" + offset + "&sort=popularity&order=descending", null, null);
    }
    public JSONArray favoriteWorlds(int offset) throws Exception {
        return (JSONArray) request("GET", "/worlds/favorites?n=50&offset=" + offset, null, null);
    }
    public JSONObject world(String wid) throws Exception {
        return (JSONObject) request("GET", "/worlds/" + id(wid, "wrld"), null, null);
    }
    public void removeFavorite(String fid) throws Exception {
        request("DELETE", "/favorites/" + id(fid, "fvrt"), null, null);
    }
    public JSONArray favoriteGroups() throws Exception {
        return (JSONArray) request("GET", "/favorite/groups?type=world&ownerId=" + id(me().getString("id"), "usr") + "&n=100", null, null);
    }
    public void addWorld(String world, String group) throws Exception {
        request("POST", "/favorites", new JSONObject().put("type", "world").put("favoriteId", id(world, "wrld")).put("tags", new JSONArray().put(group)), null);
    }
    public JSONObject status(String uid, String state, String description) throws Exception {
        return (JSONObject) request("PUT", "/users/" + id(uid, "usr"), new JSONObject().put("status", state).put("statusDescription", description), null);
    }
    public void boop(String uid) throws Exception { request("POST", "/users/" + id(uid, "usr") + "/boop", new JSONObject(), null); }
    public JSONObject events(String month, int offset) throws Exception {
        return (JSONObject) request("GET", "/calendar?date=" + q(month) + "&n=100&offset=" + offset, null, null);
    }
    public JSONArray notifications(int offset) throws Exception {
        return (JSONArray) request("GET", "/auth/user/notifications?n=100&offset=" + offset, null, null);
    }
    public JSONArray notificationsV2() throws Exception {
        return (JSONArray) request("GET", "/notifications?limit=100", null, null);
    }
    public void logout() throws Exception {
        try { request("PUT", "/logout", new JSONObject(), null); } finally { cookies.clear(); }
    }
}
