package de.vrcpocket;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends Activity {
    private PocketApp app;
    private LinearLayout root, page, navigation;
    private TextView connection;
    private JSONObject me;
    private int tab=0, generation=0, offset=0;
    private boolean offline=false, favorites=false;
    private String query="";
    private YearMonth month=YearMonth.now();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private static final int BG=0xff10141e, CARD=0xff1c2433, INK=0xfff0f5ff, MUTED=0xffaab7ca, MINT=0xff70e6c5;
    interface Work<T> { T run() throws Exception; }
    interface Done<T> { void accept(T value) throws Exception; }
    private String t(String de,String en){return app.t(de,en);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved); app=(PocketApp)getApplication();
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
        login();
        if(!app.api.cookies.auth().isEmpty()) task(() -> app.api.me(), user -> authenticated(user), null);
    }
    private TextView text(String value,int size,int color){
        TextView v=new TextView(this); v.setText(value); v.setTextSize(size);v.setTextColor(color);v.setPadding(0,dp(5),0,dp(5)); return v;
    }
    private GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private LinearLayout column(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);return c;}
    private LinearLayout row(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);return c;}
    private Button button(String label,Runnable action){
        Button b=new Button(this);b.setText(label);b.setTextColor(MINT);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(dp(48));
        b.setOnClickListener(v -> action.run());return b;
    }
    private EditText input(String hint,boolean password){
        EditText e=new EditText(this);e.setHint(hint);e.setTextColor(INK);e.setHintTextColor(MUTED);e.setSingleLine(true);
        e.setInputType(password?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_TEXT);
        e.setPadding(dp(12),dp(12),dp(12),dp(12));e.setBackground(shape(CARD,12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,dp(6),0,dp(6));e.setLayoutParams(lp);return e;
    }
    private void shell(String heading,String sub,boolean tabs){
        generation++;root=column();root.setBackgroundColor(BG);
        // Insets keep Android 15 edge-to-edge content clear of system bars.
        root.setOnApplyWindowInsetsListener((view,insets)->{
            view.setPadding(dp(18)+insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),dp(18)+insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;
        });
        TextView brand=text("VRC POCKET",12,MINT);brand.setLetterSpacing(.18f);root.addView(brand);
        TextView title=text(heading,30,INK);title.setTypeface(null,Typeface.BOLD);root.addView(title);
        if(!sub.isEmpty())root.addView(text(sub,13,MUTED));
        connection=text("",12,MINT);if(tabs){root.addView(connection);updateConnection();}
        ScrollView scroll=new ScrollView(this);page=column();page.setPadding(0,dp(8),0,dp(16));scroll.addView(page);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(tabs){
            navigation=row();String[] labels={t("Freunde","Friends"),t("Welten","Worlds"),t("Events","Events"),t("Inbox","Inbox"),t("Profil","Profile")};
            for(int i=0;i<labels.length;i++){final int n=i;Button b=button(labels[i],()->{tab=n;offset=0;render();});b.setTextSize(11);b.setPadding(0,0,0,0);b.setTextColor(i==tab?MINT:MUTED);navigation.addView(b,new LinearLayout.LayoutParams(0,dp(56),1));}
            root.addView(navigation);
        }
        setContentView(root);root.requestApplyInsets();
    }
    private void login(){
        me=null;shell(t("Dein VRChat. Unterwegs.","Your VRChat. On the go."),t("Freunde · Welten · Events","Friends · Worlds · Events"),false);
        page.addView(text(t("Melde dich mit deinem VRChat-Konto an. Passwort und Zwei-Faktor-Code werden nicht gespeichert. Deine Sitzung bleibt verschlüsselt auf diesem Gerät.","Sign in with your VRChat account. Password and two-factor code are not saved. Your session stays encrypted on this device."),15,MUTED));
        EditText user=input(t("VRChat-Benutzername","VRChat username"),false),password=input(t("Passwort","Password"),true);page.addView(user);page.addView(password);
        Button sign=button(t("Anmelden","Sign in"),()->{
            if(user.getText().toString().trim().isEmpty()||password.length()==0){toast(t("Benutzername und Passwort eingeben","Enter username and password"));return;}
            String name=user.getText().toString().trim(),pass=password.getText().toString();password.setText("");
            task(()->app.api.login(name,pass),this::authenticated,null);
        });page.addView(sign);
        page.addView(button("Deutsch / English",()->{app.prefs.edit().putString("language",app.prefs.getString("language","de").equals("de")?"en":"de").apply();login();}));
        page.addView(text(t("Unabhängige Companion-App · Alpha 0.1\nKein offizielles Produkt von VRChat. Ein reines Steam-/Meta-Konto muss zuerst mit einem VRChat-Konto verknüpft werden.","Independent companion app · Alpha 0.1\nNot an official VRChat product. A Steam/Meta-only account must first be linked to a VRChat account."),12,MUTED));
    }
    private void authenticated(JSONObject user)throws Exception{
        if(user.has("requiresTwoFactorAuth")){twoFactor(user.getJSONArray("requiresTwoFactorAuth"));return;}
        if(!user.has("id"))throw new IllegalStateException("Missing user");
        me=user;render();
    }
    private void twoFactor(JSONArray methods){
        shell(t("Anmeldung bestätigen","Verify sign-in"),t("Zwei-Faktor-Authentifizierung","Two-factor authentication"),false);
        List<String> types=new ArrayList<>();for(int i=0;i<methods.length();i++){String type=methods.optString(i);if(type.equals("totp")||type.equals("emailOtp")||type.equals("otp"))types.add(type);}
        if(types.isEmpty()){page.addView(text(t("Diese Anmeldemethode wird noch nicht unterstützt.","This authentication method is not supported yet."),16,MUTED));page.addView(button(t("Zurück","Back"),this::login));return;}
        Spinner method=new Spinner(this);List<String> labels=new ArrayList<>();for(String type:types)labels.add(type.equals("totp")?t("Authenticator","Authenticator"):type.equals("emailOtp")?t("E-Mail-Code","Email code"):t("Wiederherstellungscode","Recovery code"));
        method.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));page.addView(method);
        EditText code=input(t("Bestätigungscode","Verification code"),false);page.addView(code);
        page.addView(button(t("Bestätigen","Verify"),()->{String value=code.getText().toString().trim();code.setText("");task(()->app.api.verify(types.get(method.getSelectedItemPosition()).toLowerCase(Locale.ROOT),value),this::authenticated,null);}));
        page.addView(button(t("Abbrechen","Cancel"),()->{app.api.cookies.clear();login();}));
    }
    private void render(){
        if(me==null){login();return;}
        switch(tab){case 0:friends();break;case 1:worlds();break;case 2:events();break;case 3:inbox();break;default:profile();}
    }
    private LinearLayout card(String title,String detail){
        LinearLayout card=column();card.setPadding(dp(14),dp(10),dp(14),dp(10));card.setBackground(shape(CARD,16));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));card.setLayoutParams(lp);
        TextView name=text(title,18,INK);name.setTypeface(null,Typeface.BOLD);card.addView(name);
        if(!detail.isEmpty())card.addView(text(detail,13,MUTED));page.addView(card);return card;
    }
    private void friends(){
        shell(t("Deine Freunde","Your friends"),t("Online sehen. In Verbindung bleiben.","See who's online. Stay connected."),true);
        page.addView(button(offline?t("Offline · zu Online wechseln","Offline · show online"):t("Online · zu Offline wechseln","Online · show offline"),()->{offline=!offline;offset=0;friends();}));
        task(()->app.api.friends(offline,offset),batch->{
            if(batch.length()==0)page.addView(text(t("Keine Freunde auf dieser Seite.","No friends on this page."),15,MUTED));
            for(int i=0;i<batch.length();i++){
                JSONObject u=batch.getJSONObject(i);String uid=u.getString("id"),name=u.optString("displayName",uid);
                String loc=u.optString("location",offline?"offline":"");
                String where=AlertPolicy.safeLocation(loc,t("Privater Standort","Private location"),t("Offline / nicht verfügbar","Offline / unavailable"));
                if(loc.startsWith("wrld_"))where=t("In einer sichtbaren VRChat-Instanz","In a visible VRChat instance");
                LinearLayout c=card((offline?"○ ":"● ")+name,statusLabel(u.optString("status"))+"\n"+where);
                Set<String> watched=app.prefs.getStringSet("watched",Collections.emptySet());
                c.addView(button(watched.contains(uid)?t("★ Beobachtet","★ Watching"):t("☆ Benachrichtigungen auswählen","☆ Watch this friend"),()->{
                    Set<String> next=new HashSet<>(app.prefs.getStringSet("watched",Collections.emptySet()));if(!next.add(uid))next.remove(uid);
                    app.prefs.edit().putStringSet("watched",next).apply();friends();
                }));
                LinearLayout actions=row();actions.addView(button("Boop",()->confirm(t("Boop senden?","Send Boop?"),name,()->task(()->{app.api.boop(uid);return true;},x->toast(t("Boop gesendet","Boop sent")),null))));
                actions.addView(button(t("Profil öffnen","Open profile"),()->open("https://vrchat.com/home/user/"+uid)));c.addView(actions);
                if(loc.startsWith("wrld_")){String wid=loc.split(":",2)[0];c.addView(button(t("Standort anzeigen","Show location"),()->task(()->app.api.world(wid),world->{
                    new AlertDialog.Builder(this).setTitle(world.optString("name"))
                        .setMessage(name+"\n"+loc+"\n\n"+world.optString("description"))
                        .setPositiveButton(t("Welt öffnen","Open world"),(d,n)->open("https://vrchat.com/home/world/"+wid))
                        .setNegativeButton(t("Schließen","Close"),null).show();
                },null)));}
            }
            pager(batch.length()==100,this::friends,100);
        },null);
    }
    private String statusLabel(String s){switch(s){case "active":return t("Online","Online");case "join me":return t("Beitreten erwünscht","Join me");case "ask me":return t("Bitte fragen","Ask me");case "busy":return t("Nicht stören","Do not disturb");case "offline":return t("Offline","Offline");default:return s;}}
    private void worlds(){
        shell(t("Neue Orte entdecken","Discover new places"),t("Suche und deine VRChat-Weltfavoriten","Search and your VRChat world favorites"),true);
        EditText search=input(t("Welten suchen …","Search worlds …"),false);search.setText(query);page.addView(search);
        LinearLayout controls=row();controls.addView(button(t("Suchen","Search"),()->{query=search.getText().toString().trim();favorites=false;offset=0;worlds();}));
        controls.addView(button(favorites?t("Alle Welten","All worlds"):t("Meine Favoriten","My favorites"),()->{favorites=!favorites;offset=0;worlds();}));page.addView(controls);
        task(()->favorites?app.api.favoriteWorlds(offset):app.api.worlds(query,offset),batch->{
            if(batch.length()==0)page.addView(text(t("Keine Welten gefunden.","No worlds found."),15,MUTED));
            for(int i=0;i<batch.length();i++){
                JSONObject w=batch.getJSONObject(i);String wid=w.optString("id"),name=w.optString("name",wid);
                LinearLayout c=card(name,w.optString("authorName")+" · "+w.optInt("occupants")+t(" Besucher"," visitors")+"\n"+w.optString("description"));
                c.addView(button(t("Details öffnen","Open details"),()->open("https://vrchat.com/home/world/"+wid)));
                if(!favorites)c.addView(button(t("Zu VRChat-Favoriten hinzufügen","Add to VRChat favorites"),()->chooseFavorite(wid)));
                else if(w.optString("favoriteId").startsWith("fvrt_"))c.addView(button(t("Favorit entfernen","Remove favorite"),()->confirm(t("Favorit entfernen?","Remove favorite?"),name,()->task(()->{app.api.removeFavorite(w.optString("favoriteId"));return true;},x->worlds(),null))));
            }
            pager(batch.length()==50,this::worlds,50);
        },null);
    }
    private void chooseFavorite(String wid){
        task(()->app.api.favoriteGroups(),groups->{
            List<String> names=new ArrayList<>(),ids=new ArrayList<>();
            for(int i=0;i<groups.length();i++){JSONObject g=groups.getJSONObject(i);if(!g.optString("type").equals("world"))continue;ids.add(g.optString("name"));names.add(g.optString("displayName",g.optString("name")));}
            if(ids.isEmpty()){toast(t("Keine Weltfavoritengruppe verfügbar","No world favorite group available"));return;}
            new AlertDialog.Builder(this).setTitle(t("Favoritengruppe","Favorite group")).setItems(names.toArray(new String[0]),(d,n)->task(()->{app.api.addWorld(wid,ids.get(n));return true;},x->toast(t("Favorit gespeichert","Favorite saved")),null)).setNegativeButton(t("Abbrechen","Cancel"),null).show();
        },null);
    }
    private void events(){
        shell(t("Dein Eventkalender","Your event calendar"),t("Kalender deines VRChat-Kontos · lokale Uhrzeit","Your VRChat account calendar · local time"),true);
        LinearLayout nav=row();nav.addView(button("‹",()->{month=month.minusMonths(1);offset=0;events();}));nav.addView(text(month.toString(),18,INK));nav.addView(button("›",()->{month=month.plusMonths(1);offset=0;events();}));page.addView(nav);
        task(()->app.api.events(month.atDay(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toString(),offset),result->{
            JSONArray batch=result.optJSONArray("results");if(batch==null)throw new JSONException("Unexpected calendar response");
            if(batch.length()==0)page.addView(text(t("Keine Termine in diesem Monat.","No events this month."),15,MUTED));
            for(int i=0;i<batch.length();i++){
                JSONObject event=batch.getJSONObject(i);String title=event.optString("title");
                LinearLayout c=card(title,date(event.optString("startsAt"))+" — "+date(event.optString("endsAt"))+"\n"+event.optString("description"));
                c.addView(button(t("Im Handy-Kalender vormerken","Add to phone calendar"),()->calendar(event)));
                if(event.optString("ownerId").startsWith("grp_"))c.addView(button(t("Veranstalter öffnen","Open organizer"),()->open("https://vrchat.com/home/group/"+event.optString("ownerId"))));
            }
            pager(result.optBoolean("hasNext",batch.length()==100),this::events,100);
        },null);
    }
    private String date(String iso){try{return Instant.parse(iso).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd.MM. HH:mm"));}catch(Exception e){return iso;}}
    private void calendar(JSONObject event){
        try{
            Intent intent=new Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI)
                .putExtra(android.provider.CalendarContract.Events.TITLE,event.optString("title"))
                .putExtra(android.provider.CalendarContract.Events.DESCRIPTION,event.optString("description"))
                .putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME,Instant.parse(event.getString("startsAt")).toEpochMilli())
                .putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME,Instant.parse(event.getString("endsAt")).toEpochMilli());
            startActivity(intent);
        }catch(Exception e){toast(t("Kein Kalender verfügbar oder Termin ungültig","No calendar available or invalid event"));}
    }
    private void inbox(){
        shell(t("Deine Aktivitäten","Your activity"),t("Benachrichtigungen und lokal erfasste Aktivitäten","Notifications and locally observed activity"),true);
        try{
            JSONArray log=new JSONArray(app.prefs.getString("activityLog","[]"));
            page.addView(text(t("Lokal erfasst","Observed locally"),16,MINT));
            if(log.length()==0)page.addView(text(t("Noch keine Aktivitäten erfasst. Starte die Überwachung im Profil.","No activity recorded yet. Start monitoring in Profile."),14,MUTED));
            for(int i=0;i<log.length();i++){JSONObject n=log.getJSONObject(i);card(n.optString("title"),n.optString("body")+"\n"+date(Instant.ofEpochMilli(n.optLong("at")).toString()));}
        }catch(Exception ignored){}
        page.addView(text(t("VRChat-Benachrichtigungen","VRChat notifications"),16,MINT));
        task(()->app.api.notifications(offset),batch->{
            if(batch.length()==0)page.addView(text(t("Keine Benachrichtigungen.","No notifications."),14,MUTED));
            for(int i=0;i<batch.length();i++){JSONObject n=batch.getJSONObject(i);card(n.optString("senderUsername","VRChat"),n.optString("type")+"\n"+n.optString("message"));}
            pager(batch.length()==100,this::inbox,100);
        },null);
        task(()->app.api.notificationsV2(),batch->{
            page.addView(text(t("Gruppen und Events","Groups and events"),16,MINT));
            for(int i=0;i<batch.length();i++){JSONObject n=batch.getJSONObject(i);card(n.optString("title",n.optString("type")),n.optString("message"));}
        },null);
    }
    private void toggle(String de,String en,String key,boolean def){
        Switch v=new Switch(this);v.setText(t(de,en));v.setTextColor(INK);v.setPadding(0,dp(12),0,dp(12));v.setChecked(app.prefs.getBoolean(key,def));v.setOnCheckedChangeListener((b,checked)->app.prefs.edit().putBoolean(key,checked).apply());page.addView(v);
    }
    private void profile(){
        shell(me.optString("displayName"),t("Dein Status und deine Einstellungen","Your status and settings"),true);
        String[] states={"active","join me","ask me","busy","offline"};List<String> labels=new ArrayList<>();for(String s:states)labels.add(statusLabel(s));
        Spinner status=new Spinner(this);status.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));
        status.setSelection(Math.max(0,Arrays.asList(states).indexOf(me.optString("status"))));page.addView(status);
        EditText description=input(t("Statustext","Status message"),false);description.setText(me.optString("statusDescription"));page.addView(description);
        page.addView(button(t("Status speichern","Save status"),()->task(()->app.api.status(me.getString("id"),states[status.getSelectedItemPosition()],description.getText().toString()),user->{me=user;toast(t("Status gespeichert","Status saved"));},null)));
        page.addView(text(t("Benachrichtigungen","Notifications"),20,MINT));
        LinearLayout controls=row();controls.addView(button(t("Überwachung starten","Start monitoring"),this::startMonitor));controls.addView(button(t("Stoppen","Stop"),()->{stopService(new Intent(this,MonitorService.class));app.prefs.edit().putString("monitorState","stopped").apply();updateConnection();}));page.addView(controls);
        toggle("Freunde online / offline","Friends online / offline","alertFriends",true);
        toggle("Nur ausgewählte Freunde melden","Only notify for watched friends","watchOnly",false);
        toggle("Weltwechsel melden","Notify world changes","alertLocations",false);
        toggle("Boops melden","Notify Boops","alertBoops",true);
        toggle("Eventbenachrichtigungen melden","Notify event notifications","alertEvents",true);
        toggle("Einladungen und weitere Meldungen","Invites and other notifications","alertOther",true);
        page.addView(text(t("Die Überwachung läuft als sichtbarer Hintergrunddienst. Android, Funklöcher und VRChat-Ausfälle können Meldungen verzögern. Nach erzwungenem Beenden oder Neustart bitte hier wieder starten. Verpasste Weltwechsel lassen sich nicht vollständig rekonstruieren.","Monitoring runs as a visible foreground service. Android, lost connectivity and VRChat outages can delay alerts. After force-stop or reboot, start it here again. Missed world changes cannot be fully recovered."),13,MUTED));
        page.addView(button(t("Android: Akku und Benachrichtigungen","Android: battery and notifications"),()->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())))));
        page.addView(text(t("App-Sprache","App language"),20,MINT));
        page.addView(button("Deutsch / English",()->{app.prefs.edit().putString("language",app.prefs.getString("language","de").equals("de")?"en":"de").apply();profile();}));
        page.addView(button(t("Lokalen Aktivitätsverlauf löschen","Clear local activity history"),()->confirm(t("Verlauf löschen?","Clear history?"),t("Die lokalen Aktivitäten werden gelöscht.","Local activity records will be deleted."),()->{app.prefs.edit().remove("activityLog").apply();toast(t("Verlauf gelöscht","History cleared"));})));
        page.addView(button(t("Abmelden","Sign out"),()->confirm(t("Abmelden?","Sign out?"),t("Überwachung stoppen und lokale Kontodaten entfernen.","Stop monitoring and remove local account data."),this::logout)));
        page.addView(text(t("Alpha 0.1 · Keine Analyse- oder Werbedienste. Standortangaben respektieren die von VRChat gelieferten Sichtbarkeitsgrenzen.","Alpha 0.1 · No analytics or advertising services. Locations respect visibility limits provided by VRChat."),12,MUTED));
    }
    private void logout(){
        stopService(new Intent(this,MonitorService.class));
        app.api.http.dispatcher().cancelAll();
        task(()->{try{app.api.logout();}catch(Exception ignored){app.api.cookies.clear();}return true;},x->{
            app.prefs.edit().remove("watched").remove("seenNotifications").remove("notificationsSeeded").remove("activityLog").putString("monitorState","stopped").apply();
            getSystemService(NotificationManager.class).cancelAll();login();
        },null);
    }
    private void startMonitor(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},12);return;}
        startForegroundService(new Intent(this,MonitorService.class));toast(t("Überwachung startet","Monitoring starting"));
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==12){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)startMonitor();else toast(t("Bitte Benachrichtigungen in Android erlauben","Please allow notifications in Android settings"));}}
    private void updateConnection(){
        if(connection==null)return;
        String s=app.prefs.getString("monitorState","stopped");long beat=app.prefs.getLong("monitorHeartbeat",0);
        if(s.equals("connected")&&System.currentTimeMillis()-beat>90000)s="stale";
        String label;switch(s){case "connected":label=t("● Live-Verbindung aktiv","● Live connection active");break;case "connecting":label=t("◌ Verbinde …","◌ Connecting …");break;case "reconnecting":label=t("◌ Verbindung unterbrochen · neuer Versuch","◌ Disconnected · retrying");break;case "login":label=t("○ Sitzung abgelaufen · erneut anmelden","○ Session expired · sign in again");break;case "stale":label=t("○ Verbindung nicht bestätigt · im Profil neu starten","○ Connection unconfirmed · restart in Profile");break;default:label=t("○ Überwachung aus · im Profil starten","○ Monitoring off · start in Profile");}
        connection.setText(label);
    }
    private final Runnable tick=new Runnable(){public void run(){updateConnection();handler.postDelayed(this,5000);}};
    @Override public void onResume(){super.onResume();handler.removeCallbacks(tick);handler.post(tick);}
    @Override public void onPause(){handler.removeCallbacks(tick);super.onPause();}
    @Override public void onDestroy(){generation++;handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void pager(boolean next,Runnable action,int size){LinearLayout r=row();if(offset>0)r.addView(button(t("Zurück","Previous"),()->{offset=Math.max(0,offset-size);action.run();}));r.addView(button(t("Aktualisieren","Refresh"),action));if(next)r.addView(button(t("Weiter","Next"),()->{offset+=size;action.run();}));page.addView(r);}
    private <T> void task(Work<T> work,Done<T> done,Runnable onError){
        final int token=generation;final LinearLayout target=page;final ProgressBar progress=new ProgressBar(this);target.addView(progress);
        app.io.execute(()->{try{T result=work.run();runOnUiThread(()->{
            if(isFinishing()||isDestroyed()||generation!=token)return;target.removeView(progress);
            try{done.accept(result);}catch(Exception e){error(e,onError);}
        });}catch(Exception e){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed()&&generation==token){target.removeView(progress);error(e,onError);}});}});
    }
    private void error(Exception e,Runnable onError){
        String message=t("Verbindung fehlgeschlagen. Bitte erneut versuchen.","Connection failed. Please try again.");
        if(e instanceof Api.ApiError){int code=((Api.ApiError)e).status;
            if(code==401)message=t("Anmeldung oder Code ungültig, oder Sitzung abgelaufen.","Invalid credentials/code, or session expired.");
            else if(code==429)message=t("VRChat begrenzt Anfragen. Bitte etwas warten.","VRChat is limiting requests. Please wait before retrying.");
            else if(code==403)message=t("VRChat hat die Anfrage abgelehnt.","VRChat denied the request.");
            else message=t("Anfrage fehlgeschlagen (HTTP ","Request failed (HTTP ")+code+").";
        }
        card(t("Nicht geladen","Could not load"),message).addView(button(t("Erneut versuchen","Retry"),()->{if(me==null)login();else render();}));if(onError!=null)onError.run();
        if(e instanceof Api.ApiError&&((Api.ApiError)e).status==401&&me!=null){stopService(new Intent(this,MonitorService.class));page.addView(button(t("Neu anmelden","Sign in again"),()->{app.api.cookies.clear();login();}));}
    }
    private void confirm(String title,String message,Runnable yes){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton(t("Bestätigen","Confirm"),(d,w)->yes.run()).setNegativeButton(t("Abbrechen","Cancel"),null).show();}
    private void open(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(ActivityNotFoundException e){toast(t("Kein Browser verfügbar","No browser available"));}}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
}
