package de.vrcpocket;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Bounded duplicate suppression; initial snapshots never generate presence alerts. */
public final class AlertPolicy {
    private final Map<String, String> last = new LinkedHashMap<>();
    private final Map<String, Boolean> notifications = new LinkedHashMap<>();
    public synchronized boolean presence(String user, String state, boolean watchOnly, Set<String> watched) {
        String previous = last.put(user, state);
        if (last.size() > 5000) last.remove(last.keySet().iterator().next());
        return previous != null && !previous.equals(state) && (!watchOnly || watched.contains(user));
    }
    public synchronized void baseline(String user, String state) { last.put(user, state); }
    public synchronized boolean notification(String id) {
        if (id.isEmpty() || notifications.containsKey(id)) return false;
        notifications.put(id, true);
        if (notifications.size() > 500) notifications.remove(notifications.keySet().iterator().next());
        return true;
    }
    public static long retryDelay(int attempt) { return Math.min(60000L, 1000L << Math.min(Math.max(attempt, 0), 6)); }
    public static String safeLocation(String location, String privateText, String offlineText) {
        if (location == null || location.isEmpty() || location.equals("offline")) return offlineText;
        if (location.equals("private")) return privateText;
        if (location.equals("traveling")) return "…";
        return location;
    }
}
