package de.vrcpocket;

import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;
import okhttp3.*;

/** User-started ongoing monitor. No password storage, boot receiver or hidden service. */
public class MonitorService extends Service {
    static final String STOP = "de.vrcpocket.STOP";
    private PocketApp app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AlertPolicy policy = new AlertPolicy();
    private WebSocket socket;
    private volatile boolean stopping;
    private boolean connecting;
    private int retry;
    private volatile long epoch;
    private final Map<String, String> names = new ConcurrentHashMap<>();
    private final Map<String, String> states = new ConcurrentHashMap<>();
    private final Runnable reconnect = this::connect;
    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            if (stopping) return;
            if (app.prefs.getString("monitorState", "").equals("connected")) {
                app.prefs.edit().putLong("monitorHeartbeat", System.currentTimeMillis()).apply();
                updateOngoing(app.t("Verbunden · überwacht Aktivitäten", "Connected · monitoring activity"));
            }
            main.postDelayed(this, 30000);
        }
    };
    @Override public void onCreate() {
        super.onCreate(); app = (PocketApp)getApplication();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("monitor", app.t("Hintergrundverbindung", "Background connection"), NotificationManager.IMPORTANCE_LOW));
        nm.createNotificationChannel(new NotificationChannel("activity", app.t("VRChat Aktivitäten", "VRChat activity"), NotificationManager.IMPORTANCE_DEFAULT));
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) { stopping = true; stopSelf(); return START_NOT_STICKY; }
        startForeground(1, ongoing(app.t("Verbindung wird aufgebaut …", "Connecting …")));
        if (!connecting && socket == null) { main.removeCallbacks(reconnect); connect(); }
        main.removeCallbacks(heartbeat); main.post(heartbeat);
        return START_NOT_STICKY;
    }
    private Notification ongoing(String message) {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, MonitorService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, "monitor").setSmallIcon(de.vrcpocket.R.drawable.ic_pocket)
            .setContentTitle("VRC Pocket").setContentText(message).setOngoing(true).setContentIntent(open)
            .addAction(new Notification.Action.Builder(null, app.t("Stoppen", "Stop"), stop).build()).build();
    }
    private void updateOngoing(String message) { getSystemService(NotificationManager.class).notify(1, ongoing(message)); }
    private void state(String value) {
        app.prefs.edit().putString("monitorState", value).putLong("monitorStateAt", System.currentTimeMillis()).apply();
    }
    private void connect() {
        if (stopping || connecting || socket != null) return;
        connecting = true; state("connecting");
        final long generation = ++epoch;
        worker.execute(() -> {
            try {
                JSONObject me = app.api.me();
                if (!me.has("id")) { main.post(this::expired); return; }
                // Baseline first, and reconcile presence after a reconnect without alert floods.
                for (boolean offline : new boolean[]{false, true}) {
                    for (int offset = 0; !stopping; offset += 100) {
                        JSONArray batch = app.api.friends(offline, offset);
                        for (int i=0; i<batch.length(); i++) {
                            JSONObject friend = batch.getJSONObject(i); String id = friend.getString("id");
                            names.put(id, friend.optString("displayName", id));
                            String state = offline ? "offline" : friend.optString("location", "online");
                            states.put(id, state); policy.baseline(id, state);
                        }
                        if (batch.length()<100) break;
                    }
                }
                // First start silently seeds existing notifications. Reconnects recover unseen IDs.
                JSONArray batch = app.api.notifications(0);
                JSONArray v2 = app.api.notificationsV2();
                for (int i=0;i<v2.length();i++) batch.put(v2.get(i));
                Set<String> seen = new HashSet<>(app.prefs.getStringSet("seenNotifications", Collections.emptySet()));
                boolean seeded = app.prefs.getBoolean("notificationsSeeded", false);
                for (int i=batch.length()-1; i>=0; i--) {
                    JSONObject n=batch.getJSONObject(i); String id=n.optString("id");
                    if (seeded && !seen.contains(id)) notification(n);
                    if (!id.isEmpty()) seen.add(id);
                }
                app.prefs.edit().putStringSet("seenNotifications", bounded(seen)).putBoolean("notificationsSeeded", true).apply();
                main.post(() -> {
                    if (stopping || generation != epoch) return;
                    Request req = new Request.Builder().url("wss://pipeline.vrchat.cloud/?authToken=" + Api.q(app.api.cookies.auth())).header("User-Agent", Api.UA).build();
                    socket=app.api.http.newWebSocket(req, new WebSocketListener() {
                        @Override public void onOpen(WebSocket ws, Response response) { main.post(() -> {
                            if (generation != epoch || stopping) { ws.cancel(); return; }
                            connecting=false; retry=0; state("connected");
                            app.prefs.edit().putLong("monitorHeartbeat", System.currentTimeMillis()).apply();
                            updateOngoing(app.t("Verbunden · überwacht Aktivitäten", "Connected · monitoring activity"));
                        }); }
                        @Override public void onMessage(WebSocket ws, String text) { if (!stopping && generation==epoch) process(text); }
                        @Override public void onFailure(WebSocket ws, Throwable error, Response response) { main.post(() -> {
                            if (generation != epoch || stopping) return;
                            if(response != null && (response.code()==401 || response.code()==403)) expired(); else failed();
                        }); }
                        @Override public void onClosing(WebSocket ws, int code, String reason) { ws.close(code, null); }
                        @Override public void onClosed(WebSocket ws, int code, String reason) { main.post(() -> { if (generation==epoch && !stopping) failed(); }); }
                    });
                });
            } catch (Api.ApiError e) { main.post(() -> { if (e.status==401 || e.status==403) expired(); else failed(); }); }
            catch (Exception e) { main.post(this::failed); }
        });
    }
    private void expired() {
        state("login"); stopping=true;
        updateOngoing(app.t("Bitte erneut anmelden", "Please sign in again")); stopSelf();
    }
    private void failed() {
        if(stopping) return;
        ++epoch;
        if(socket!=null) socket.cancel(); socket=null; connecting=false;
        state("reconnecting"); updateOngoing(app.t("Unterbrochen · neuer Versuch folgt", "Disconnected · retry scheduled"));
        main.removeCallbacks(reconnect); main.postDelayed(reconnect, AlertPolicy.retryDelay(retry++) + new Random().nextInt(1000));
    }
    private void process(String raw) {
        try {
            JSONObject envelope = new JSONObject(raw); String type=envelope.optString("type");
            if(envelope.has("err")) {
                if(envelope.optString("err").toLowerCase(Locale.ROOT).contains("authtoken")) main.post(this::expired);
                else main.post(this::failed);
                return;
            }
            Object content=envelope.opt("content");
            JSONObject data=content instanceof JSONObject ? (JSONObject)content : new JSONObject(String.valueOf(content));
            if(type.equals("notification") || type.equals("notification-v2")) { notification(data); return; }
            if(!type.startsWith("friend-")) return;
            String id=data.optString("userId"); if(id.isEmpty()) return;
            JSONObject user=data.optJSONObject("user");
            if(user!=null && user.has("displayName")) names.put(id, user.optString("displayName"));
            String name=names.getOrDefault(id, app.t("Freund", "Friend"));
            if(type.equals("friend-delete")) { states.remove(id); names.remove(id); return; }
            if(type.equals("friend-online") || type.equals("friend-offline") || type.equals("friend-location")) {
                String location = type.equals("friend-offline") ? "offline" : data.optString("location", user==null ? "online" : user.optString("location", "online"));
                states.put(id, location);
                boolean send=policy.presence(id, location, app.prefs.getBoolean("watchOnly", false), app.prefs.getStringSet("watched", Collections.emptySet()));
                boolean enabled=type.equals("friend-location") ? app.prefs.getBoolean("alertLocations", false) : app.prefs.getBoolean("alertFriends", true);
                if(send && enabled) {
                    String description=type.equals("friend-offline") ? app.t("ist offline", "is offline") : type.equals("friend-online") ? app.t("ist online", "is online") : app.t("hat die Welt gewechselt", "changed worlds");
                    alert(name, description, "presence:"+id+":"+location);
                }
            }
        } catch(Exception ignored) { /* Unknown schema: ignore; never log token-bearing frames. */ }
    }
    private synchronized void notification(JSONObject n) {
        String id=n.optString("id");
        Set<String> seen=new HashSet<>(app.prefs.getStringSet("seenNotifications", Collections.emptySet()));
        if(seen.contains(id) || !policy.notification(id)) return;
        seen.add(id); app.prefs.edit().putStringSet("seenNotifications", bounded(seen)).apply();
        String type=n.optString("type").toLowerCase(Locale.ROOT);
        boolean isBoop=type.contains("boop"), isEvent=type.contains("event") || type.contains("calendar") || n.optString("category").equals("event");
        if(!app.prefs.getBoolean(isBoop ? "alertBoops" : isEvent ? "alertEvents" : "alertOther", true)) return;
        alert(n.optString("senderUsername", "VRChat"), isBoop ? app.t("hat dir einen Boop geschickt", "sent you a Boop") : isEvent ? app.t("Neue Eventbenachrichtigung", "New event notification") : app.t("Neue Benachrichtigung: ", "New notification: ")+n.optString("type"), id);
    }
    private Set<String> bounded(Set<String> source) {
        if(source.size()<=500) return source;
        // Keep bounded storage. API IDs are opaque; order is unimportant for this replay window.
        return new HashSet<>(new ArrayList<>(source).subList(source.size()-500, source.size()));
    }
    private synchronized void alert(String title, String body, String key) {
        if(stopping) return;
        try {
            JSONArray log=new JSONArray(app.prefs.getString("activityLog", "[]")); JSONArray next=new JSONArray();
            next.put(new JSONObject().put("title", title).put("body", body).put("at", System.currentTimeMillis()));
            for(int i=0;i<Math.min(99, log.length());i++) next.put(log.get(i));
            app.prefs.edit().putString("activityLog", next.toString()).apply();
        } catch(JSONException ignored) {}
        PendingIntent open=PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n=new Notification.Builder(this, "activity").setSmallIcon(de.vrcpocket.R.drawable.ic_pocket)
            .setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(open).build();
        try { getSystemService(NotificationManager.class).notify(100 + (key.hashCode() & 0x7fffffff)%100000, n); } catch(SecurityException ignored) {}
    }
    @Override public void onDestroy() {
        stopping=true; ++epoch; main.removeCallbacksAndMessages(null);
        if(socket!=null) socket.cancel(); worker.shutdownNow();
        if(!app.prefs.getString("monitorState", "").equals("login")) state("stopped");
        stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
